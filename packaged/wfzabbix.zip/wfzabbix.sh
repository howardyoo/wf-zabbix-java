#!/bin/sh
java -Xmx2048m -Xms1024m -jar wf-zabbix-1.0-RELEASE.jar
